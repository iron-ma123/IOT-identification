import request from '@/utils/request'

export default {
  login(data) {
    return request({
      url: '/pki-client/login',
      method: 'post',
      data
    })
  },
  register(data) {
    return request({
      url: '/pki-client/register',
      method: 'post',
      data
    })
  },
  getInfo() {
    return request({
      url: '/pki-client/api/getInfo',
      method: 'get'
    })
  },
  getSystemInfo() {
    return request({
      url: '/curve/param',
      method: 'get'
    })
  }
}
