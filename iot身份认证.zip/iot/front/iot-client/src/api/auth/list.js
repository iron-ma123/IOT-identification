import request from '@/utils/request'

export default {
  getServerList() {
    return request({
      url: '/pki-client/api/query-servers',
      method: 'get'
    })
  },
  authToServer(data) {
    return request({
      url: '/pki-client/auth',
      method: 'post',
      data
    })
  },
  getAuths() {
    return request({
      url: '/pki-client/api/query-auths',
      method: 'get'
    })
  }
}
