export default {
  blurString(str, start, end) {
    var startStr = str.substr(0, start)
    var len = str.length
    var endStr = str.substr(len - end)
    return startStr + '****' + endStr
  }

}
