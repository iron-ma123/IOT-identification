<template>
  <div class="dashboard-container">
    <el-descriptions title="系统配置信息" class="margin-top" :column="1" border>
      <el-descriptions-item label="type">{{ systemInfo.type }}</el-descriptions-item>
      <el-descriptions-item label="q">{{ systemInfo.q }}</el-descriptions-item>
      <el-descriptions-item label="h">{{ systemInfo.h }}</el-descriptions-item>
      <el-descriptions-item label="r">{{ systemInfo.r }}</el-descriptions-item>
      <el-descriptions-item label="exp1">{{ systemInfo.exp1 }}</el-descriptions-item>
      <el-descriptions-item label="exp2">{{ systemInfo.exp2 }}</el-descriptions-item>
      <el-descriptions-item label="sign0">{{ systemInfo.sign0 }}</el-descriptions-item>
      <el-descriptions-item label="sign1">{{ systemInfo.sign1 }}</el-descriptions-item>
      <el-descriptions-item label="generatorOnG1Field">{{ systemInfo.generatorOnG1Field }}</el-descriptions-item>
      <el-descriptions-item label="systemPublicKey">{{ systemInfo.systemPublicKey }}</el-descriptions-item>
    </el-descriptions>

  </div>
</template>

<script>
import user from '@/api/user/user'

export default {
  name: 'Dashboard',
  data() {
    return {
      dialogVisible: false,
      systemInfo: {
        type: '',
        q: '',
        h: '',
        r: '',
        exp1: '',
        exp2: '',
        sign1: '',
        sign0: '',
        generatorOnG1Field: '',
        systemPublicKey: ''
      }
    }
  },
  created() {
    this.getInfo()
  },
  methods: {
    getInfo() {
      user.getSystemInfo()
        .then(response => {
          var data = response.data
          this.systemInfo.type = data.curveMetadata.type
          this.systemInfo.q = data.curveMetadata.q
          this.systemInfo.h = data.curveMetadata.h
          this.systemInfo.r = data.curveMetadata.r
          this.systemInfo.exp1 = data.curveMetadata.exp1
          this.systemInfo.exp2 = data.curveMetadata.exp2
          this.systemInfo.sign1 = data.curveMetadata.sign1
          this.systemInfo.sign0 = data.curveMetadata.sign0
          this.systemInfo.generatorOnG1Field = data.generatorOnG1Field
          this.systemInfo.systemPublicKey = data.systemPublicKey
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }

  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
