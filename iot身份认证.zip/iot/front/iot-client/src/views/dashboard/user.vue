<template>
  <div class="dashboard-container">
    <el-descriptions title="用户信息" class="margin-top" :column="1" border>
      <template slot="extra">
        <el-button type="primary" size="small" @click="dialogVisible = true">查看完整信息</el-button>
      </template>
      <el-descriptions-item label="用户ID">{{ userInfo.id }}</el-descriptions-item>
      <el-descriptions-item label="身份信息">{{ userInfo.acd }}</el-descriptions-item>
      <el-descriptions-item label="消息哈希">{{ userInfo.delta }}</el-descriptions-item>
      <el-descriptions-item label="签名">{{ userInfo.sigma }}</el-descriptions-item>
      <el-descriptions-item label="公钥">{{ userInfo.pk }}</el-descriptions-item>
      <el-descriptions-item label="私钥">{{ userInfo.password }}</el-descriptions-item>
    </el-descriptions>

    <el-dialog title="完整信息" :visible.sync="dialogVisible">
      <el-descriptions class="margin-top" :column="1" border>
        <el-descriptions-item label="用户ID">{{ userInfo.id }}</el-descriptions-item>
        <el-descriptions-item label="身份信息">{{ userInfo.acdOri }}</el-descriptions-item>
        <el-descriptions-item label="消息哈希">{{ userInfo.deltaOri }}</el-descriptions-item>
        <el-descriptions-item label="签名">{{ userInfo.sigmaOri }}</el-descriptions-item>
        <el-descriptions-item label="公钥">{{ userInfo.pkOri }}</el-descriptions-item>
        <el-descriptions-item label="私钥">{{ userInfo.passwordOri }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script>
import user from '@/api/user/user'
import utils from '@/utils/utils'

export default {
  name: 'Dashboard',
  data() {
    return {
      userInfo: {
        id: '',
        acd: '',
        acdOri: '',
        delta: '',
        deltaOri: '',
        sigma: '',
        sigmaOri: '',
        pk: '',
        pkOri: '',
        password: '',
        passwordOri: ''
      },
      dialogVisible: false,
    }
  },
  created() {
    this.getInfo()
  },
  methods: {
    getInfo() {
      user.getInfo()
        .then(response => {
          var data = response.data
          this.userInfo.id = data.id
          this.userInfo.acdOri = data.acd
          this.userInfo.acd = utils.blurString(data.acd, 3, 3)
          this.userInfo.sigmaOri = data.sigma
          this.userInfo.sigma = utils.blurString(data.sigma, 3, 3)
          this.userInfo.deltaOri = data.delta
          this.userInfo.delta = utils.blurString(data.delta, 3, 3)
          this.userInfo.pkOri = data.pk
          this.userInfo.pk = utils.blurString(data.pk, 3, 3)
          this.userInfo.passwordOri = data.privateSeed
          this.userInfo.password = utils.blurString(data.privateSeed, 3, 3)
        })
    },
    open() {

    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }

  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
