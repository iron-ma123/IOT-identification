<template>
  <div class="login-register">
    <div class="contain">
      <div class="big-box" :class="{active:isLogin}">
        <div v-if="isLogin" key="bigContainLogin" class="big-contain">
          <div class="btitle">物联网项目认证模块</div>
          <br>
          <div class="btitle">客户端账户登录</div>
          <div class="bform">
            <input v-model="userInfo.id" type="id" placeholder="用户ID">
            <input v-model="userInfo.seed" type="password" placeholder="密码">
          </div>
          <button class="bbutton" @click="login">登录</button>
        </div>

        <div v-else key="bigContainRegister" class="big-contain">
          <div class="btitle">物联网项目认证模块</div>
          <br>
          <div class="btitle">创建客户端账户</div>
          <div class="bform">
            <input v-model="userInfo.id" type="text" placeholder="用户ID">
            <input v-model="userInfo.seed" type="password" placeholder="密码">
          </div>
          <button class="bbutton" @click="register">注册</button>
        </div>
      </div>

      <div class="small-box" :class="{active:isLogin}">
        <div v-if="isLogin" key="smallContainRegister" class="small-contain">
          <div class="stitle">你好，朋友!</div>
          <p class="scontent">开始注册</p>
          <button class="sbutton" @click="changeType">注册</button>
        </div>
        <div v-else key="smallContainLogin" class="small-contain">
          <div class="stitle">欢迎回来!</div>
          <p class="scontent">请登录你的账户</p>
          <button class="sbutton" @click="changeType">登录</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import userProcess from '@/api/user/user'
import {  setToken } from '@/utils/auth'
export default {
  name: 'LoginRegister',
  data() {
    return {
      userInfo: {
        id: '',
        seed: ''
      },
      isLogin: false,
      emailError: false,
      passwordError: false,
      existed: false,
      rules: {
        id: [
          {required: true, message: '请输入用户ID', trigger: 'blur'},
          {min: 3, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur'}
        ],
        seed: [
          {required: true, message: '请输入密码', trigger: 'blur'}
        ]
      }
    }
  },
  methods: {
    changeType() {
      this.isLogin = !this.isLogin
      this.userInfo.id = ''
      this.userInfo.seed = ''
    },
    register() {
      userProcess.register(this.userInfo)
        .then(response => {
          this.$message({
            message: '注册成功，请登陆',
            type: 'success'
          })
        })
    },

    login() {
      userProcess.login(this.userInfo)
        .then(response => {
          var token = response.data.token
          setToken(token)
          this.$router.push({ path: '/' })
        }).catch(err => {

      })
    }
  }
}
</script>

<style scoped="scoped">
.login-register {
  width: 100vw;
  height: 100vh;
  box-sizing: border-box;
}

.contain {
  width: 60%;
  height: 60%;
  position: relative;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  border-radius: 20px;
  box-shadow: 0 0 3px #f0f0f0,
  0 0 6px #f0f0f0;
}

.big-box {
  width: 70%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 30%;
  transform: translateX(0%);
  transition: all 1s;
}

.big-contain {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.btitle {
  font-size: 1.5em;
  font-weight: bold;
  color: rgb(57, 167, 176);
}

.bform {
  width: 100%;
  height: 40%;
  padding: 2em 0;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
}

.bform .errTips {
  display: block;
  width: 50%;
  text-align: left;
  color: red;
  font-size: 0.7em;
  margin-left: 1em;
}

.bform input {
  width: 50%;
  height: 30px;
  border: none;
  outline: none;
  border-radius: 10px;
  padding-left: 2em;
  background-color: #f0f0f0;
}

.bbutton {
  width: 20%;
  height: 40px;
  border-radius: 24px;
  border: none;
  outline: none;
  background-color: rgb(57, 167, 176);
  color: #fff;
  font-size: 0.9em;
  cursor: pointer;
}

.small-box {
  width: 30%;
  height: 100%;
  background: linear-gradient(135deg, rgb(57, 167, 176), rgb(56, 183, 145));
  position: absolute;
  top: 0;
  left: 0;
  transform: translateX(0%);
  transition: all 1s;
  border-top-left-radius: inherit;
  border-bottom-left-radius: inherit;
}

.small-contain {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.stitle {
  font-size: 1.5em;
  font-weight: bold;
  color: #fff;
}

.scontent {
  font-size: 0.8em;
  color: #fff;
  text-align: center;
  padding: 2em 4em;
  line-height: 1.7em;
}

.sbutton {
  width: 60%;
  height: 40px;
  border-radius: 24px;
  border: 1px solid #fff;
  outline: none;
  background-color: transparent;
  color: #fff;
  font-size: 0.9em;
  cursor: pointer;
}

.big-box.active {
  left: 0;
  transition: all 0.5s;
}

.small-box.active {
  left: 100%;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-top-right-radius: inherit;
  border-bottom-right-radius: inherit;
  transform: translateX(-100%);
  transition: all 1s;
}
</style>

<!-- Home.vue

//在methods中定义请求方法，并return出去，不要写请求回调then()
methods:{
    getAllTask:function(){
     console.log('调用第一个接口')
     return this.$axios({
              url:'http://192.168.*.**:***/api/getTask/getAllData',
              method:'GET',
              params:{
                offset:1,
                pageSize:10
              }
            })
    },
    getAllCity:function(){
     console.log('调用第二个接口')
     return this.$axios({
                url:'http://192.168.*.**:***/city/getCities',
                method:'GET',
              })
    }
  },
//在mounted周期同时发送两个请求，并在请求都结束后，输出结果
 mounted:function(){
    var me = this;
    this.$axios.all([me.getAllTask(),me.getAllCity()])
    .then(me.$axios.spread(function(allTask, allCity){
        console.log('所有请求完成')
        console.log('请求1结果',allTask)
        console.log('请求2结果',allCity)

    }))

  } -->
