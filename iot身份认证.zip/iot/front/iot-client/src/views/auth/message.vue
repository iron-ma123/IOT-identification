<template>
  <div class="app-container">
    <el-table
      :data="authInfoList"
      max-height="800"
      border
      style="width: 100%"
    >

      <el-table-column
        fixed
        prop="id"
        label="消息ID"
        width="100"
      />

      <el-table-column
        prop="clientId"
        label="客户端ID"
        width="100"
      />

      <el-table-column
        prop="serverId"
        label="服务器ID"
        width="100"
      />

      <el-table-column
        prop="c"
        label="中间参数c"
        width="250"
      />

      <el-table-column
        prop="r1"
        label="中间参数r1"
        width="600"
      />

      <el-table-column
        prop="r2"
        label="中间参数r2"
        width="600"
      />

      <el-table-column label="状态" width="80" fixed="right">
        <template slot-scope="scope">
          <span v-if="scope.row.status===0" style="color:skyblue">等待认证</span>
          <span v-else-if="scope.row.status===1" style="color:green">认证成功</span>
          <span v-else style="color:red">认证失败</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import list from '@/api/auth/list'

export default {
  data() {
    return {
      authInfoList: []
    }
  },
  created() {
    this.getAuths()
  },
  methods: {
    getAuths() {
      list.getAuths()
        .then(response => {
          this.authInfoList = response.data
        })
        .catch(err => {
          console.log(err)
        })
    }
  }

}

</script>
