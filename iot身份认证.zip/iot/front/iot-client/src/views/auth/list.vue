<template>
  <div class="app-container">
    <el-table
      :data="serverList"
      max-height="800"
      border
      style="width: 100%"
    >

      <el-table-column
        fixed
        prop="id"
        label="ID"
        width="60"
      />

      <el-table-column
        prop="publicFirst"
        label="部分公钥1"
        width="600"
      />

      <el-table-column
        prop="publicSecond"
        label="部分公钥2"
        width="600"
      />

      <el-table-column
        prop="gama"
        label="中间参数Gama"
        width="250"
      />

      <el-table-column
        fixed="right"
        label="操作"
        width="100"
      >
        <template slot-scope="scope">
          <el-button type="text" size="big" @click="auth(scope.row)">消息认证</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import list from '@/api/auth/list'

export default {
  data() {
    return {
      serverList: []
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      list.getServerList()
        .then(response => {
          this.serverList = response.data
        }).catch(err => {
        console.log(err)
      })
    },
    auth(serverInfo) {
      this.$prompt('请输入待认证消息', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      })
        .then(({value}) => {
          var authInfo = {'serverId': serverInfo.id, 'message': value}
          list.authToServer(authInfo).then(response => {
            this.$message({
              type: 'success',
              message: '认证消息发送成功，等待服务器处理'
            })
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
    }
  }

}

</script>
