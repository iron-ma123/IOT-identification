<template>
  <div class="app-container">
    <el-table
      :data="authInfoList"
      max-height="800"
      border
      style="width: 100%"
    >

      <el-table-column
        fixed
        prop="id"
        label="消息ID"
        width="100"
      />

      <el-table-column
        prop="clientId"
        label="客户端ID"
        width="100"
      />

      <el-table-column
        prop="serverId"
        label="服务器ID"
        width="100"
      />

      <el-table-column
        prop="c"
        label="中间参数c"
        width="250"
      />

      <el-table-column
        prop="r1"
        label="中间参数r1"
        width="600"
      />

      <el-table-column
        prop="r2"
        label="中间参数r2"
        width="600"
      />

      <el-table-column label="状态" width="80">
        <template slot-scope="scope">
          <span v-if="scope.row.status===0" style="color:skyblue">等待认证</span>
          <span v-else-if="scope.row.status===1" style="color:green">认证成功</span>
          <span v-else style="color:red">认证失败</span>
        </template>
      </el-table-column>

      <el-table-column label="操作" width="80" fixed="right">
        <template slot-scope="scope">
          <span v-if="scope.row.status===0" style="color:skyblue" @click="auth(scope.row)">
            <el-button type="primary" plain>认证</el-button>
          </span>
          <span v-else-if="scope.row.status===1" style="color:green">
            <el-button type="info" plain disabled>认证</el-button>
          </span>
          <span v-else style="color:red">
            <el-button type="info" plain>认证</el-button>
          </span>
        </template>
      </el-table-column>
      <el-button type="primary" plain>认证</el-button>
    </el-table>

    <el-dialog title="完整信息" :visible.sync="dialogVisible">
      <el-descriptions class="margin-top" :column="1" border>
        <el-descriptions-item label="clientId">{{ authResponse.clientId }}</el-descriptions-item>
        <el-descriptions-item label="serverId">{{ authResponse.serverId }}</el-descriptions-item>
        <el-descriptions-item label="authMessage">{{ authResponse.authMessage }}</el-descriptions-item>
        <el-descriptions-item label="mac">{{ authResponse.mac }}</el-descriptions-item>
        <el-descriptions-item label="timestamp">{{ authResponse.timestamp }}</el-descriptions-item>
        <el-descriptions-item label="sessionKey">{{ authResponse.sessionKey }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>

  </div>
</template>

<script>
import list from '@/api/auth/list'

export default {
  data() {
    return {
      authInfoList: [],
      dialogVisible: false,
      authResponse: {
        clientId: '',
        serverId: '',
        authMessage: '',
        mac: '',
        timestamp: '',
        sessionKey: ''
      }
    }
  },
  created() {
    this.getAuths()
  },
  methods: {
    getAuths() {
      list.getAuths()
        .then(response => {
          this.authInfoList = response.data
        })
        .catch(err => {
          console.log(err)
        })
    },
    auth(data) {
      var authInfoId = data.id
      list.authMessage(authInfoId)
        .then(response => {
          this.$message({
            message: '认证成功，请查看认证信息',
            type: 'success',
            onClose: () => {
              location.reload()
            }
          })
          data = response.data
          this.authResponse.clientId = data.clientId
          this.authResponse.serverId = data.serverId
          this.authResponse.authMessage = data.authMessage
          this.authResponse.mac = data.mac
          this.authResponse.timestamp = data.timestamp
          this.authResponse.sessionKey = data.sessionKey
          this.dialogVisible = true
        })
    }
  }
}

</script>
