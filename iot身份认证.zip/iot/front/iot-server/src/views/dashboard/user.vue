<template>
  <div class="dashboard-container">
    <el-descriptions title="用户信息" class="margin-top" :column="1" border>
      <template slot="extra">
        <el-button type="primary" size="small" @click="dialogVisible = true">查看完整信息</el-button>
      </template>
      <el-descriptions-item label="用户ID">{{ userInfo.id }}</el-descriptions-item>
      <el-descriptions-item label="部分公钥1">{{ userInfo.publicFirst }}</el-descriptions-item>
      <el-descriptions-item label="部分公钥2">{{ userInfo.publicSecond }}</el-descriptions-item>
      <el-descriptions-item label="中间参数gamma">{{ userInfo.gama }}</el-descriptions-item>
      <el-descriptions-item label="用户私钥1">{{ userInfo.privateFirst }}</el-descriptions-item>
    </el-descriptions>

    <el-dialog title="完整信息" :visible.sync="dialogVisible">
      <el-descriptions class="margin-top" :column="1" border>
        <el-descriptions-item label="用户ID">{{ userInfo.id }}</el-descriptions-item>
        <el-descriptions-item label="部分公钥1">{{ userInfo.publicFirstOri }}</el-descriptions-item>
        <el-descriptions-item label="部分公钥2">{{ userInfo.publicSecondOri }}</el-descriptions-item>
        <el-descriptions-item label="中间参数gamma">{{ userInfo.gamaOri }}</el-descriptions-item>
        <el-descriptions-item label="用户私钥1">{{ userInfo.privateFirstOri }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script>
import user from '@/api/user/user'
import utils from '@/utils/utils'

export default {
  name: 'Dashboard',
  data() {
    return {
      userInfo: {
        id: '',
        privateFirst: '',
        privateFirstOri: '',
        publicFirst: '',
        publicFirstOri: '',
        publicSecond: '',
        publicSecondOri: '',
        gama: '',
        gamaOri: '',
        password: '',
        passwordOri: ''
      },
      dialogVisible: false,
    }
  },
  created() {
    this.getInfo()
  },
  methods: {
    getInfo() {
      user.getInfo()
        .then(response => {
          var data = response.data
          this.userInfo.id = data.id
          this.userInfo.publicFirstOri = data.publicFirst
          this.userInfo.publicFirst = utils.blurString(data.publicFirst, 3, 3)
          this.userInfo.publicSecondOri = data.publicSecond
          this.userInfo.publicSecond = utils.blurString(data.publicSecond, 3, 3)
          this.userInfo.gamaOri = data.gama
          this.userInfo.gama = utils.blurString(data.gama, 3, 3)
          this.userInfo.privateFirstOri = data.privateFirst
          this.userInfo.privateFirst = utils.blurString(data.privateFirst, 3, 3)
          this.userInfo.passwordOri = data.privateSeed
          this.userInfo.password = utils.blurString(data.privateSeed, 3, 3)
        })
    },
    open() {

    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }

  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
