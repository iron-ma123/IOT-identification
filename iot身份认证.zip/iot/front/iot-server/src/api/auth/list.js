import request from '@/utils/request'

export default {
  authMessage(authId) {
    return request({
      url: '/clc-server/auth/' + authId,
      method: 'get'
    })
  },
  getAuths() {
    return request({
      url: '/clc-server/api/query-auths',
      method: 'get'
    })
  }
}
