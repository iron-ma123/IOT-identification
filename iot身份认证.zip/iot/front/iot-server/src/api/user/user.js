import request from '@/utils/request'

export default {
  login(data) {
    return request({
      url: '/clc-server/login',
      method: 'post',
      data
    })
  },
  register(data) {
    return request({
      url: '/clc-server/register',
      method: 'post',
      data
    })
  },
  getInfo() {
    return request({
      url: '/clc-server/api/getInfo',
      method: 'get'
    })
  },
  getSystemInfo() {
    return request({
      url: '/curve/param',
      method: 'get'
    })
  }
}
