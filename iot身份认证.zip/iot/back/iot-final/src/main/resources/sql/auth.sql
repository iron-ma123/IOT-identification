/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.26 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table if not exists `auth` (
	`id` int (11),
	`client_id` varchar (765),
	`server_id` varchar (765),
	`c` varchar (1536),
	`r1` varchar (1536),
	`r2` varchar (1536),
	`r3` varchar (1536),
	`r4` varchar (1536),
	`u` varchar (1536),
	`message_len` int (11),
	`status` tinyint (4)
); 
