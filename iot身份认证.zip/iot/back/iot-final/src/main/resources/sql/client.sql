/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.26 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table if not exists `client` (
	`id` varchar (765),
	`acd` varchar (765),
	`sigma` varchar (765),
	`delta` varchar (765),
	`pk` varchar (765),
	`private_seed` char (132)
); 
