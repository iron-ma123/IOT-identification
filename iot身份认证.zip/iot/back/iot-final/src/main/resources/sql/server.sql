/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.26 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table if not exists `server` (
	`id` varchar (765),
	`private_first` varchar (765),
	`public_first` varchar (765),
	`public_second` varchar (765),
	`gama` varchar (765),
	`private_seed` char (132)
); 
