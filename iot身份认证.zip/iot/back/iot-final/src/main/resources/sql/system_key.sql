/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 8.0.26 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table if not exists `system_key` (
	`secret_seed` varchar (765),
	`generator_seed` varchar (765)
); 
insert into `system_key` (`secret_seed`, `generator_seed`) values('53514038bed0446fa214152d46906d74','91d14baa6a954b9f90df39ac6ff1aead');
