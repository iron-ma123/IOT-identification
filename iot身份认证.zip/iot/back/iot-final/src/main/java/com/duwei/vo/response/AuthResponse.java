package com.duwei.vo.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *  客户端与服务器的认证结果
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 11:38
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthResponse {
    private String clientId;
    private String serverId;
    private String authMessage;
    // 消息验证码
    private byte[] mac;
    private long timestamp;
    private byte[] sessionKey;
}
