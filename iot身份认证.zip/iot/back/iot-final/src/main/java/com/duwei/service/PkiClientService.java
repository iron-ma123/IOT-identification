package com.duwei.service;

import com.duwei.cache.ClcServerCache;
import com.duwei.cache.PkiClientCache;
import com.duwei.common.Result;
import com.duwei.dao.ClcServerDao;
import com.duwei.dao.PkiClientDao;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.entity.Server;
import com.duwei.entity.internal.ClcServer;
import com.duwei.entity.internal.PkiClient;
import com.duwei.session.PkiClientHolder;
import com.duwei.start.NetworkManager;
import com.duwei.util.HashUtils;
import com.duwei.util.TokenUtils;
import com.duwei.vo.ClientAuthVO;
import com.duwei.vo.LoginVO;
import com.duwei.vo.request.AuthRequest;
import com.duwei.vo.request.RegisterRequest;
import com.duwei.vo.response.ClientLoginResponse;
import it.unisa.dia.gas.jpbc.Element;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Service
public class PkiClientService {
    @Resource
    private PkiClientDao pkiClientDao;
    @Resource
    private NetworkManager networkManager;
    @Resource
    private ClcServerDao clcServerDao;
    @Resource
    private AuthService authService;

    public Result<List<Server>> queryServers() {
        List<Server> servers = clcServerDao.queryServers();
        servers.sort(Comparator.comparing(Server::getId));
        return Result.ok(clcServerDao.queryServers());
    }

    public Result<Client> register(RegisterRequest registerRequest) {
        String id = registerRequest.getId();
        String seed = registerRequest.getSeed();
        // 1.查询对应的clientId是否存在，不允许重复
        Client client = pkiClientDao.queryClient(id);
        if (client != null) {
            return Result.fail(500, "客户端ID重复，请重新注册");
        }

        // 2.构建PKI客户端实例
        PkiClient pkiClient = new PkiClient(id, seed, networkManager.getSystemParam());

        // 3. 进行注册
        List<Element> elements = networkManager.registerClient(id, pkiClient.getPk().getImmutable());

        // 4.PKI客户端进行验证
        boolean success = pkiClient.verify(elements.get(0), elements.get(1), elements.get(2));
        if (!success) {
            return Result.fail(500, "客户端验证失败");
        }

        // 5.将客户端信息放入数据库
        client = convert(pkiClient);
        pkiClientDao.saveClient(convert(pkiClient));

        return Result.ok(client);
    }

    public Result<ClientLoginResponse> login(LoginVO loginVO) {
        String id = loginVO.getId();
        String seed = loginVO.getSeed();
        seed = Base64Utils.encodeToString(HashUtils.sha256(seed.getBytes(StandardCharsets.UTF_8)));
        Client client = pkiClientDao.queryClient(id, seed);
        if (client == null) {
            return Result.fail(500, "账号不存在或者种子错误");
        }
        String token = TokenUtils.token();
        PkiClient pkiClient = new PkiClient(client, loginVO.getSeed(), networkManager.getSystemParam());
        PkiClientCache.INSTANCE.addCache(token, pkiClient);
        return Result.ok(new ClientLoginResponse(client, token));
    }


    public Client convert(PkiClient pkiClient) {
        Client client = new Client();
        client.setId(pkiClient.getId());
        client.setPrivateSeed(Base64Utils.encodeToString(HashUtils.sha256(pkiClient.getSeed().getBytes(StandardCharsets.UTF_8))));
        client.setPk(Base64Utils.encodeToString(pkiClient.getPk().toBytes()));
        client.setSigma(Base64Utils.encodeToString(pkiClient.getSigma().toBytes()));
        client.setDelta(Base64Utils.encodeToString(pkiClient.getDelta().toBytes()));
        client.setAcd(Base64Utils.encodeToString(pkiClient.getAcd().toBytes()));
        return client;
    }


    public Result<Auth> authToServer(ClientAuthVO clientAuthVO) {
        String serverId = clientAuthVO.getServerId();
        String message = clientAuthVO.getMessage();
        Server server = clcServerDao.queryServer(serverId);
        if (server == null) {
            return Result.fail(500, "待认证的服务器不存在");
        }
        PkiClient pkiClient = PkiClientHolder.get();
        Auth auth = authService.queryAuthSuccess(pkiClient.getId(), serverId);
        if (auth != null) {
            return Result.fail(500, "该客户端已经向服务器进行过认证，无需再次认证", auth);
        }

        auth = authService.queryNoAuth(pkiClient.getId(), serverId);
        if (auth != null) {
            return Result.fail(500, "该客户端已经向服务器提交认证请求，请等待服务器处理", auth);
        }

        auth = pkiClient.authServer(message, server);
        authService.save(auth);
        return Result.ok(auth);
    }

    public Result<List<Auth>> queryAuths() {
        PkiClient pkiClient = PkiClientHolder.get();
        return authService.queryByClientId(pkiClient.getId());
    }

    public Result<Client> getInfo() {
        PkiClient pkiClient = PkiClientHolder.get();
        return Result.ok(pkiClientDao.queryClient(pkiClient.getId()));
    }
}
