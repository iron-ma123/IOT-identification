package com.duwei.controller;

import com.duwei.common.Result;
import com.duwei.entity.Auth;
import com.duwei.entity.Server;
import com.duwei.service.ClcServerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2024-04-26 08:57
 * @since: 1.0
 */
@RestController
@CrossOrigin
@RequestMapping("/clc-server/api")
public class ServerApiController {
    @Autowired
    private ClcServerService clcServerService;

    @GetMapping("/getInfo")
    public Result<Server> getInfo(){
        return clcServerService.getInfo();
    }

//    @GetMapping("/query-servers")
//    public Result<List<Server>> queryServers() {
//        return pkiClientService.queryServers();
//    }


    @GetMapping("/query-auths")
    public Result<List<Auth>> queryAuths(){
        return clcServerService.queryAuths();
    }

}
