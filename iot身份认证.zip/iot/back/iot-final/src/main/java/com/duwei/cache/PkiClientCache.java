package com.duwei.cache;

import com.duwei.entity.internal.PkiClient;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:12
 * @since: 1.0
 */
public class PkiClientCache extends Cache<String, PkiClient> {
    public static final PkiClientCache INSTANCE = new PkiClientCache();

    public static void add(String token, PkiClient pkiClient) {
        INSTANCE.addCache(token, pkiClient);
    }

    public static PkiClient get(String token) {
        return INSTANCE.getCache(token);
    }
}
