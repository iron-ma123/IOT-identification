package com.duwei.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-25 17:08
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pair<A,B> {
    private A first;
    private B second;
}
