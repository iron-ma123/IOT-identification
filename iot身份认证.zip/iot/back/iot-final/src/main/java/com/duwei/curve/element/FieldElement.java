package com.duwei.curve.element;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;

/**
 * <p>
 *  可传输的元素接口
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 16:12
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
public interface FieldElement {
    Element toElement(Field field);
}
