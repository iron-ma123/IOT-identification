package com.duwei.curve.param;

import com.duwei.curve.medatada.CurvePropertiesParametersAdapter;
import com.duwei.curve.medatada.TypeACurveMetadata;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import lombok.Data;

/**
 * <p>
 * 椭圆曲线的基本参数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 15:21
 * @since: 1.0
 */
@Data
@SuppressWarnings("rawtypes")
public class CurveBaseParam {
    private Pairing pairing;
    private Field g1Field;
    private Field g2Field;
    private Field gtField;
    private Field zrField;
    private TypeACurveMetadata curveMetadata;

    public CurveBaseParam(TypeACurveMetadata curveMetadata) {
        CurvePropertiesParametersAdapter adapter = new CurvePropertiesParametersAdapter(curveMetadata);
        Pairing pairing = PairingFactory.getPairing(adapter);
        this.pairing = pairing;
        this.gtField = pairing.getGT();
        this.g1Field = pairing.getG1();
        this.g2Field = pairing.getG2();
        this.zrField = pairing.getZr();
        this.curveMetadata = curveMetadata;
    }

}
