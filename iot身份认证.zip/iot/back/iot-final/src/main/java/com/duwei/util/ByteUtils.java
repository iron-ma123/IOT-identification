package com.duwei.util;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

/**
 * <p>
 * 处理byte工具类
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-24 17:20
 * @since: 1.0
 */
public class ByteUtils {

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Byte0 {
        private byte[] data;
        private int len;


        public Byte0(byte[] data) {
            this.data = data;
            this.len = data.length;
        }
    }

    /**
     * 将多个字节数组拼接
     */
    public static byte[] concat(byte[]... bytes) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        for (byte[] data : bytes) {
            outputStream.write(data, 0, data.length);
        }
        return outputStream.toByteArray();
    }

    public static byte[] trimZero(byte[] data) {
        int start = 0;
        for (int i = 0; i < data.length; i++) {
            if (data[i] != 0) {
                start = i;
                break;
            }
        }
        int end = 0;
        for (int i = data.length - 1; i >= 0; i--) {
            if (data[i] != 0) {
                end = i;
                break;
            }
        }
        return Arrays.copyOfRange(data, start, end + 1);
    }

    public static byte[] random(int len) {
        byte[] res = new byte[len];
        ThreadLocalRandom.current().nextBytes(res);
        return res;
    }

    public static byte[] xor(byte[] data1, byte[] data2) {
        byte[] lengthBytes = data1.length > data2.length ? data1 : data2;
        byte[] shortBytes = lengthBytes == data1 ? data2 : data1;
        byte[] result = new byte[lengthBytes.length];
        for (int i = 0; i < shortBytes.length; i++) {
            result[i] = (byte) (lengthBytes[i] ^ shortBytes[i]);
        }
        System.arraycopy(lengthBytes, shortBytes.length, result, shortBytes.length, lengthBytes.length - shortBytes.length);
        return result;
    }

    public static byte[] truncate(byte[] data, int len) {
        if (data.length <= len) {
            return data;
        }
        return Arrays.copyOf(data, len);
    }
}
