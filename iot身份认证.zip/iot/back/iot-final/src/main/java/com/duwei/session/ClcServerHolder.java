package com.duwei.session;

import com.duwei.entity.internal.ClcServer;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 15:31
 * @since: 1.0
 */
public class ClcServerHolder extends Holder<ClcServer> {
    private static final ClcServerHolder INSTANCE = new ClcServerHolder();

    public static void set(ClcServer clcServer){
        INSTANCE.save(clcServer);
    }

    public static void remove(){
        INSTANCE.delete();
    }

    public static ClcServer get(){
        return INSTANCE.getObj();
    }
}
