package com.duwei.vo.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:52
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    // 客户端ID
    private String id;
    // 生成私钥以及用来登录的种子
    private String seed;
}
