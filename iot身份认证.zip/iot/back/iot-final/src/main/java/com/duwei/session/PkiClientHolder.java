package com.duwei.session;

import com.duwei.entity.internal.ClcServer;
import com.duwei.entity.internal.PkiClient;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 15:31
 * @since: 1.0
 */
public class PkiClientHolder extends Holder<PkiClient> {
    private static final PkiClientHolder INSTANCE = new PkiClientHolder();

    public static void set(PkiClient pkiClient) {
        INSTANCE.save(pkiClient);
    }

    public static void remove() {
        INSTANCE.delete();
    }

    public static PkiClient get() {
        return INSTANCE.getObj();
    }
}
