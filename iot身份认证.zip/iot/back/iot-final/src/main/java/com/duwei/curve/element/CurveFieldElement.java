package com.duwei.curve.element;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.plaf.jpbc.field.curve.CurveElement;
import it.unisa.dia.gas.plaf.jpbc.field.curve.CurveField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 * <p>
 * 对jpbc的CurveElement进行的封装，可以进行传输和序列化
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 11:29
 * @since: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuppressWarnings("rawtypes")
public class CurveFieldElement extends AbstractFieldElement {
    @Override
    protected void checkElement(Element element) {
        if (!(element instanceof CurveElement)) {
            throw new RuntimeException("element 必须是 CurveElement 类型 ");
        }
    }

    @Override
    protected void checkField(Field field) {
        if (!(field instanceof CurveField)) {
            throw new RuntimeException("field 必须是 CurveField 类型");
        }
    }

    public CurveFieldElement(Element element){
        super(element);
    }

}
