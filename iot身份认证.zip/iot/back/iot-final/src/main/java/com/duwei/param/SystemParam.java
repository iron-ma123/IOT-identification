package com.duwei.param;

import com.duwei.curve.element.CurveFieldElement;
import com.duwei.curve.medatada.TypeACurveMetadata;
import com.duwei.curve.param.CurveBaseParam;
import com.duwei.util.HashUtils;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.nio.charset.StandardCharsets;

/**
 * <p>
 * 系统参数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 17:31
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("rawtypes")
public class SystemParam {
    /**
     * 椭圆曲线参数
     */
    private CurveBaseParam curveBaseParam;
    /**
     * G1上的生成元
     */
    private Element generatorOnG1Field;
    /**
     * 系统公钥
     */
    private Element systemPublicKey;
    /**
     * 系统注主私钥
     */
    private Element systemPrivateKey;

    public static SystemParam build(TypeACurveMetadata metadata,
                                    CurveFieldElement generatorOnG1Field,
                                    CurveFieldElement systemPublicKey){
        SystemParam systemParam = new SystemParam();
        CurveBaseParam curveBaseParam = new CurveBaseParam(metadata);
        Field g1Field = curveBaseParam.getG1Field();
        Element elementGenerator = generatorOnG1Field.toElement(g1Field);
        Element elementSystemPublicKey = systemPublicKey.toElement(g1Field);
        systemParam.setCurveBaseParam(curveBaseParam);
        systemParam.setGeneratorOnG1Field(elementGenerator);
        systemParam.setSystemPublicKey(elementSystemPublicKey);
        return systemParam;
    }

    public static SystemParam build(TypeACurveMetadata metadata, SystemKey systemKey) {
        CurveBaseParam curveBaseParam = new CurveBaseParam(metadata);
        String secretSeed = systemKey.getSecretSeed();
        String generatorSeed = systemKey.getGeneratorSeed();
        Field g1Field = curveBaseParam.getG1Field();
        Field zrField = curveBaseParam.getZrField();

        byte[] secretSeedHash = HashUtils.sha256(secretSeed.getBytes(StandardCharsets.UTF_8));
        byte[] generatorSeedHash = HashUtils.sha256(generatorSeed.getBytes(StandardCharsets.UTF_8));

        Element secretElement = zrField.newElementFromHash(secretSeedHash, 0, secretSeedHash.length).getImmutable();
        Element generatorElement = g1Field.newElementFromHash(generatorSeedHash, 0, generatorSeedHash.length).getImmutable();

        SystemParam systemParam = new SystemParam();
        systemParam.setCurveBaseParam(curveBaseParam);
        systemParam.setSystemPrivateKey(secretElement);
        systemParam.setGeneratorOnG1Field(generatorElement);
        systemParam.setSystemPublicKey(generatorElement.mulZn(secretElement).getImmutable());
        return systemParam;
    }
}
