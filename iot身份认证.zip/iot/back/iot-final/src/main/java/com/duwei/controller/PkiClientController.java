package com.duwei.controller;

import com.duwei.common.Result;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.service.PkiClientService;
import com.duwei.vo.ClientAuthVO;
import com.duwei.vo.LoginVO;
import com.duwei.vo.request.RegisterRequest;
import com.duwei.vo.response.ClientLoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@RestController
@CrossOrigin
@RequestMapping("/pki-client")
public class PkiClientController {
    @Autowired
    private PkiClientService pkiClientService;

    @PostMapping("/register")
    public Result<Client> register(@RequestBody RegisterRequest registerRequest) {
        return pkiClientService.register(registerRequest);
    }

    @PostMapping("/login")
    public Result<ClientLoginResponse> login(@RequestBody LoginVO loginVO){
        return pkiClientService.login(loginVO);
    }

    @PostMapping("/auth")
    public Result<Auth> authToServer(@RequestBody ClientAuthVO clientAuthVO){
        return pkiClientService.authToServer(clientAuthVO);
    }


}
