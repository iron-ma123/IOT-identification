package com.duwei.util;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.plaf.jpbc.field.curve.CurveElement;
import it.unisa.dia.gas.plaf.jpbc.field.curve.CurveField;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;


/**
 * <p>
 * 椭圆曲线的工具类
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-24 16:36
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
public class CurveUtils {
    public static <T extends Element> T sequenceToFieldWithSha256(byte[] sequence, Field<T> field) {
        byte[] hash = HashUtils.sha256(sequence);
        return field.newElementFromHash(hash, 0, hash.length);
    }

    public static <T extends Element> T sequenceToFieldWithSha512(byte[] sequence, Field<T> field) {
        byte[] hash = HashUtils.sha512(sequence);
        return field.newElementFromHash(hash, 0, hash.length);
    }


    @SuppressWarnings("rawtypes")
    public static Element hashToZrElement(byte[] sequence, Field zrField) {
        return (zrField.newElementFromHash(sequence, 0, sequence.length)).getImmutable();
    }

    @SuppressWarnings("rawtypes")
    public static Element hashToCurvesElement(byte[] sequence, Field curveField) {
        return curveField.newElementFromHash(sequence, 0, sequence.length).getImmutable();
    }


    public static Map<String,byte[]> convertMap(Map<String ,Element> map){
        Map<String,byte[]> result = new HashMap<>();
        map.forEach((key,val) -> {
            result.put(key,val.toBytes());
        });
        return result;
    }

    /**
     * 将消息嵌入到椭圆曲线上
     */
    public static Element messageEmbedToCurve(String message,Field field){
        if (!(field instanceof CurveField)){
            throw new RuntimeException("field 必须是椭圆曲线 field");
        }
        CurveElement element = (CurveElement)field.newRandomElement();
        element.setFromBytesX(message.getBytes(StandardCharsets.UTF_8));
        return element.getImmutable();
    }

    /**
     * 将椭圆曲线上元素还原回明文消息
     */
    public static byte[] curveConvertToMessage(Element element){
        if (!(element instanceof CurveElement)){
            throw new RuntimeException("field 必须是椭圆曲线 field");
        }
        CurveElement curveElement = (CurveElement) element;
        byte[] bytes = curveElement.getX().toBytes();
        return ByteUtils.trimZero(bytes);
    }

}
