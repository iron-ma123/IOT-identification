package com.duwei.dao;

import com.duwei.entity.Auth;
import com.duwei.entity.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 15:03
 * @since: 1.0
 */
@Repository
public class AuthDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Auth queryById(String clientId, String serverId) {
        String sql = "select * from auth where client_id = ? and server_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{clientId, serverId}, new BeanPropertyRowMapper<>(Auth.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public Auth queryIdAndState(String clientId, String serverId, Integer status) {
        String sql = "select * from auth where client_id = ? and server_id = ? and status = " + status;
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{clientId, serverId}, new BeanPropertyRowMapper<>(Auth.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public Auth queryById(String id) {
        String sql = "select * from auth where id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(Auth.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public void updateAuth(Auth auth) {
        String sql = "update auth set status = ? where id = ?";
        jdbcTemplate.update(sql, auth.getStatus(), auth.getId());
    }

    public void saveAuth(Auth auth) {
        String sql = "insert into auth values(null,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(
                sql,
                auth.getClientId(),
                auth.getServerId(),
                auth.getC(),
                auth.getR1(),
                auth.getR2(),
                auth.getR3(),
                auth.getR4(),
                auth.getU(),
                auth.getMessageLen(),
                auth.getStatus()
        );
    }

    public List<Auth> queryByServerId(String serverId) {
        String sql = "select * from auth where server_id = ?";
        try {
            return jdbcTemplate.query(
                    sql,
                    new Object[]{serverId},
                    new BeanPropertyRowMapper<>(Auth.class));
        } catch (Exception ignored) {

        }
        return Collections.emptyList();
    }


    public List<Auth> queryByClientId(String clientId) {
        String sql = "select * from auth where client_id = ?";
        try {
            return jdbcTemplate.query(
                    sql,
                    new Object[]{clientId},
                    new BeanPropertyRowMapper<>(Auth.class));
        } catch (Exception ignored) {

        }
        return Collections.emptyList();
    }
}
