package com.duwei.curve.medatada;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * TypeA类椭圆曲线元参数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 15:11
 * @since: 1.0
 */
@Data
@NoArgsConstructor
public class TypeACurveMetadata implements CurveMetadata, Serializable {
    private static final long serialVersionUID = 1545394302608235284L;
    private String type;
    private String q;
    private String h;
    private String r;
    private String exp2;
    private String exp1;
    private String sign1;
    private String sign0;

    /**
     * 默认参数的椭圆曲线元参数信息
     */
    public static final TypeACurveMetadata DEFAULT = new TypeACurveMetadata().defaultBuild();

    @Override
    public Map<String, String> extractMetadata() {
        Map<String, String> propertiesMap = new HashMap<>();
        propertiesMap.put(Constant.TYPE, type);
        propertiesMap.put(Constant.Q, q);
        propertiesMap.put(Constant.R, r);
        propertiesMap.put(Constant.H, h);
        propertiesMap.put(Constant.EXP1, exp1);
        propertiesMap.put(Constant.EXP2, exp2);
        propertiesMap.put(Constant.SIGN0, sign0);
        propertiesMap.put(Constant.SIGN1, sign1);
        return propertiesMap;
    }

    private interface Constant {
        String TYPE = "type";
        String Q = "q";
        String H = "h";
        String R = "r";
        String EXP1 = "exp1";
        String EXP2 = "exp2";
        String SIGN1 = "sign1";
        String SIGN0 = "sign0";
    }

    /**
     * 默认的构造方法，使用默认配置的椭圆曲线元参数信息
     */
    private TypeACurveMetadata defaultBuild() {
        this.type = "a";
        this.q = "3930575219365354715075847558061268890629065603808596099518560241110293759667298882072364788007205810519048743034911485723616073805468353541073582239278059";
        this.r = "730750818665451459101842416367364881864821047297";
        this.h = "5378817401181496627783782435620643317678636580742049708902045719111678061424728152866628683673837233791980";
        this.exp1 = "63";
        this.exp2 = "159";
        this.sign0 = "1";
        this.sign1 = "1";
        return this;
    }

}
