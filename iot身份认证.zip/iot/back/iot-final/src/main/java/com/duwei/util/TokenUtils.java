package com.duwei.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:33
 * @since: 1.0
 */
public class TokenUtils {

    public static String token() {
        String token = UUID.randomUUID().toString().replace("-", "");
        return token;
    }

}
