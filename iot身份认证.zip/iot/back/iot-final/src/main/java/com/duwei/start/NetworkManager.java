package com.duwei.start;

import com.duwei.curve.medatada.TypeACurveMetadata;

import com.duwei.dao.SystemParamDao;
import com.duwei.param.Hash;
import com.duwei.param.SystemKey;
import com.duwei.param.SystemParam;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>
 * 网络管理者
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-25 10:11
 * @since: 1.0
 */
@Data
@Component
@SuppressWarnings("rawtypes")
public class NetworkManager implements InitializingBean {
    @Autowired
    private SystemParamDao systemParamDao;

    private SystemParam systemParam;

    public NetworkManager() {
    }


    public List<Element> registerClient(String clientId, Element clientPublicKey) {
        return registerClientInternal(clientId, clientPublicKey);
    }

    /**
     * 客户端进行注册
     *
     * @param id 客户端ID
     * @param pk 客户端公钥
     * @return 身份验证信息
     */
    private List<Element> registerClientInternal(String id, Element pk) {
        // 1.计算身份hash
        Element identityHash = identityHash(id);
        // 2.计算身份账号Acd
        Element w = systemParam.getCurveBaseParam().getZrField().newRandomElement().getImmutable();
        Element p = systemParam.getGeneratorOnG1Field();
        Element acd = p.mulZn((w.add(identityHash).getImmutable())).getImmutable();
        // 3.计算Hash信息
        Element delta = Hash.h1(id.getBytes(StandardCharsets.UTF_8), pk, systemParam.getCurveBaseParam().getZrField());
        // 4.计算签名信息
        Element s = systemParam.getSystemPrivateKey();
        Element sign = (w.add(identityHash).add(delta.mulZn(s))).getImmutable();
        // 5.返回结果
        List<Element> elements = new ArrayList<>();
        elements.add(acd);
        elements.add(delta);
        elements.add(sign);
        return elements;
    }

    public List<Element> registerServer(String serverId) {
        return registerServerInternal(serverId);
    }

    private List<Element> registerServerInternal(String serverId) {
        // 1.计算T
        Element P = systemParam.getGeneratorOnG1Field();
        Element t = systemParam.getCurveBaseParam().getZrField().newRandomElement().getImmutable();
        Element T = P.mulZn(t).getImmutable();

        //2. 计算gama
        Element gama = Hash.h1(serverId.getBytes(StandardCharsets.UTF_8), T,
                systemParam.getCurveBaseParam().getZrField());

        //3.计算d
        Element d = systemParam.getSystemPrivateKey().mul(gama).getImmutable().add(t).getImmutable();

        List<Element> elements = new ArrayList<>();
        elements.add(T);
        elements.add(d);
        elements.add(gama);
        return elements;
    }

    private Element identityHash(String id) {
        Field zrField = systemParam.getCurveBaseParam().getZrField();
        return Hash.h0(id.getBytes(StandardCharsets.UTF_8), zrField);
    }



    @Override
    public void afterPropertiesSet() throws Exception {
        // 1.查询数据库的椭圆曲线参数元配置信息
        TypeACurveMetadata metadata = systemParamDao.queryCurveMetadata();
        // 2.查询网络管理者的系统密钥（s, generator）
        SystemKey systemKey = systemParamDao.querySystemKey();
        this.systemParam = SystemParam.build(metadata, systemKey);
    }
}
