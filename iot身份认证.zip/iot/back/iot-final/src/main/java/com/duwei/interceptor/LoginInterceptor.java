package com.duwei.interceptor;

import com.duwei.cache.ClcServerCache;
import com.duwei.cache.PkiClientCache;
import com.duwei.entity.internal.ClcServer;
import com.duwei.entity.internal.PkiClient;
import com.duwei.session.ClcServerHolder;
import com.duwei.session.PkiClientHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:31
 * @since: 1.0
 */
public class LoginInterceptor implements HandlerInterceptor {
    private static final String AUTHORIZATION = "Authorization";

    private static final String NO_TOKEN = "{" +
            "\"code\": 50000," +
            "\"message\": \"用户未登录，请先登录再进行操作\"," +
            "\"data\": null" +
            "}";
    private static final String ERROR_TOKEN = "{" +
            "\"code\": 50000," +
            "\"message\": \"token无效，请重新登录\"," +
            "\"data\": null" +
            "}";

    private static final String CLC_SERVER_PATH = "/clc-server";
    private static final String PKI_CLIENT_PATH = "/pki-client";


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader(AUTHORIZATION);

        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        if (token == null || token.length() == 0) {
            response.getOutputStream().write(NO_TOKEN.getBytes(StandardCharsets.UTF_8));
            return false;
        }

        String requestURI = request.getRequestURI();
        if (requestURI.contains(CLC_SERVER_PATH)) {
            ClcServer clcServer = ClcServerCache.get(token);
            if (clcServer == null) {
                response.getOutputStream().write(ERROR_TOKEN.getBytes(StandardCharsets.UTF_8));
                return false;
            }
            ClcServerHolder.set(clcServer);
            return true;
        }

        if (requestURI.contains(PKI_CLIENT_PATH)) {
            PkiClient pkiClient = PkiClientCache.get(token);
            if (pkiClient == null) {
                response.getOutputStream().write(ERROR_TOKEN.getBytes(StandardCharsets.UTF_8));
                return false;
            }
            PkiClientHolder.set(pkiClient);
            return true;
        }
        return true;
    }


    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        PkiClientHolder.remove();
        ClcServerHolder.remove();
    }
}
