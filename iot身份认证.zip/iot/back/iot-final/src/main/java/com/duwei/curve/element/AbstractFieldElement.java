package com.duwei.curve.element;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 16:13
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("rawtypes")
public abstract class AbstractFieldElement implements FieldElement {
    protected byte[] value;

    public AbstractFieldElement(Element element) {
        checkElement(element);
        this.value = element.toBytes();
    }

    @Override
    public Element toElement(Field field) {
        checkField(field);
        return field.newElementFromBytes(value).getImmutable();
    }

    protected abstract void checkElement(Element element);

    protected abstract void checkField(Field field);
}
