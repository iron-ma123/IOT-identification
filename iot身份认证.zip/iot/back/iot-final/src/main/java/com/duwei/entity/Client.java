package com.duwei.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-27 09:56
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Client {
    private String id;
    private String pk;
    private String acd;
    private String sigma;
    private String delta;
    /**
     * 用于客户端登录
     */
    private String privateSeed;
}
