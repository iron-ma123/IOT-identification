package com.duwei.session;

import java.util.Map;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 11:34
 * @since: 1.0
 */
public class Holder<T> {
    private final ThreadLocal<T> THREAD_LOCAL = new ThreadLocal<>();

    public void save(T t) {
        THREAD_LOCAL.set(t);
    }

    public void delete() {
        THREAD_LOCAL.remove();
    }

    public T getObj(){
        return THREAD_LOCAL.get();
    }
}
