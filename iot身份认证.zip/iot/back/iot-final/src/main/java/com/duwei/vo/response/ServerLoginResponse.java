package com.duwei.vo.response;

import com.duwei.entity.Server;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:50
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServerLoginResponse {
    private Server server;
    private String token;
}
