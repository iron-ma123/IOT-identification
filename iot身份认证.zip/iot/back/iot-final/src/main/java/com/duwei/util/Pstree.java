package com.duwei.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-11-09 15:00
 * @since: 1.0
 */
public class Pstree {
    static ExecutorService executorService = Executors.newFixedThreadPool(10);
    public static void main(String[] path){
        ListQueue listQueue = new ListQueue();
        executorService.execute(new Produce(listQueue));
        executorService.execute(new Produce(listQueue));
        executorService.execute(new Produce(listQueue));
        executorService.execute(new Consumer(listQueue));
        executorService.execute(new Consumer(listQueue));
        executorService.execute(new Consumer(listQueue));
    }

    static class Produce implements Runnable{
        ListQueue listQueue;

        public Produce(ListQueue listQueue) {
            this.listQueue = listQueue;
        }

        public void produce(){
            while (true){
                listQueue.printLeft();
            }
        }

        @Override
        public void run() {
            produce();
        }
    }

    static class Consumer implements Runnable{
        ListQueue listQueue;

        public Consumer(ListQueue listQueue) {
            this.listQueue = listQueue;
        }

        public void consume(){
            while (true){
                listQueue.printRight();
            }
        }

        @Override
        public void run() {
            consume();
        }

    }

    public static class ListQueue{
        static int DIFF_MAX = 8;
        int diff = 0;
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();

        public void printLeft(){
            lock.lock();
            try {
                while (diff == DIFF_MAX){
                    condition.await();
                }
                System.out.print("(");
                diff++;
                condition.signalAll();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }
        }

        public void printRight(){
            lock.lock();
            try {
                while (diff == 0){
                    condition.await();
                }
                System.out.print(")");
                diff--;
                condition.signalAll();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }
        }
    }

}
