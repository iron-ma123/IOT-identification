package com.duwei.vo;

import com.duwei.curve.element.CurveFieldElement;
import com.duwei.curve.medatada.CurveMetadata;
import com.duwei.curve.medatada.TypeACurveMetadata;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *  系统参数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-27 09:14
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemParamVO {
    private TypeACurveMetadata curveMetadata;
    private byte[] generatorOnG1Field;
    private byte[] systemPublicKey;
}
