package com.duwei.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 15:39
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientAuthVO {
    private String serverId;
    private String message;
}
