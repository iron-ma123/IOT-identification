package com.duwei.curve.medatada;

import java.util.Map;

/**
 * <p>
 *  椭圆曲线元参数信息接口
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 15:08
 * @since: 1.0
 */
public interface CurveMetadata  {
    /**
     * 获取元参数集合
     */
    Map<String,String> extractMetadata();
}
