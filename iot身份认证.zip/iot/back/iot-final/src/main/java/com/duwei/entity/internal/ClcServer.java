package com.duwei.entity.internal;

import com.duwei.common.Pair;
import com.duwei.common.Result;
import com.duwei.curve.algorithm.SignCryption;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.entity.Server;
import com.duwei.param.Hash;
import com.duwei.param.SystemParam;
import com.duwei.util.ByteUtils;
import com.duwei.util.CurveUtils;
import com.duwei.util.HashUtils;
import com.duwei.vo.request.AuthRequest;
import com.duwei.vo.response.AuthResponse;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;

import it.unisa.dia.gas.jpbc.Pairing;
import lombok.Data;
import org.springframework.util.Base64Utils;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;


/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-25 16:46
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
@Data
public class ClcServer {
    public static final long error_internal = 1000 * 5;
    private String id;
    private String seed;
    private SystemParam systemParam;
    private Element gama;
    private Pair<Element, Element> privateKeyPair;
    private Pair<Element, Element> publicKeyPair;

    public ClcServer(String id, String seed, SystemParam systemParam) {
        this.id = id;
        this.seed = seed;
        this.systemParam = systemParam;
        this.init();
    }

    public ClcServer(Server server, String seed, SystemParam systemParam) {
        this.id = server.getId();
        this.seed = seed;
        this.systemParam = systemParam;
        this.init();
        this.build(server.getPublicFirst(), server.getPrivateFirst(), server.getGama());
    }

    public void init() {
        byte[] hash = HashUtils.sha256(seed.getBytes(StandardCharsets.UTF_8));
        Element P = this.systemParam.getGeneratorOnG1Field();
        Field Zr = this.systemParam.getCurveBaseParam().getZrField();
        Element xc = Zr.newElementFromHash(hash, 0, hash.length).getImmutable();
        Element Pkc = P.mulZn(xc).getImmutable();
        this.publicKeyPair = new Pair<>();
        this.privateKeyPair = new Pair<>();
        publicKeyPair.setSecond(Pkc);
        privateKeyPair.setSecond(xc);
    }


    public boolean verify(Element TElement,
                          Element dElement,
                          Element gamaElement) {
        Element P = systemParam.getGeneratorOnG1Field().getImmutable();
        Element pPub = systemParam.getSystemPublicKey().getImmutable();
        Pairing pairing = systemParam.getCurveBaseParam().getPairing();

        Element left = pairing.pairing(P.mulZn(dElement).getImmutable(), P).getImmutable();
        Element right_1 = pairing.pairing(TElement, P).getImmutable();
        Element right_2 = pairing.pairing(pPub, P.mulZn(gamaElement).getImmutable()).getImmutable();
        Element right = right_1.mul(right_2).getImmutable();
        boolean success = right.equals(left);
        if (success) {
            this.gama = gamaElement;
            this.publicKeyPair.setFirst(TElement);
            this.privateKeyPair.setFirst(dElement);
        }
        return success;
    }

    public void build(String firstPublicKey, String firstPrivateKey, String gama) {
        byte[] upperT = Base64Utils.decodeFromString(firstPublicKey);
        byte[] d = Base64Utils.decodeFromString(firstPrivateKey);
        byte[] gamaByte = Base64Utils.decodeFromString(gama);

        Element TElement = systemParam.getCurveBaseParam().getG1Field().newElementFromBytes(upperT).getImmutable();
        Element dElement = systemParam.getCurveBaseParam().getZrField().newElementFromBytes(d).getImmutable();
        Element gamaElement = systemParam.getCurveBaseParam().getZrField().newElementFromBytes(gamaByte).getImmutable();
        privateKeyPair.setFirst(dElement);
        publicKeyPair.setFirst(TElement);
        this.gama = gamaElement;
    }


    public Result<AuthResponse> auth(AuthRequest authRequest,Client client,Auth auth) {
        Field Zr = systemParam.getCurveBaseParam().getZrField();
        Field G1 = systemParam.getCurveBaseParam().getG1Field();
        Element d = privateKeyPair.getFirst().getImmutable();
        Element P = systemParam.getGeneratorOnG1Field().getImmutable();
        Element xc = privateKeyPair.getSecond().getImmutable();
        Element c = authRequest.getSignCryptionText().getC().getImmutable();

        SignCryption.SignCryptionText signCryptionText = authRequest.getSignCryptionText();
        Element U = signCryptionText.getU();
        byte[] R2 = signCryptionText.getR2();
        byte[] R3 = signCryptionText.getR3();

        Element temp = U.sub(P.mulZn(d).getImmutable()).getImmutable();
        Element R1 = temp.mulZn(xc.invert().getImmutable()).getImmutable();

        byte[] k = ByteUtils.xor(R3, Hash.h3(R2));
        byte[] mBytes = ByteUtils.xor(R2, Hash.h3(k));
        mBytes = ByteUtils.truncate(mBytes, signCryptionText.getMessageLen());
        Element m = CurveUtils.messageEmbedToCurve(new String(mBytes), G1);

        Element cP = P.mulZn(c).getImmutable();
        Element H4_m = Hash.h4(m.toBytes(), Zr);
        Element H4_m_pk = authRequest.getClientPublicKey().mulZn(H4_m).getImmutable();
        Element right = cP.sub(H4_m_pk).getImmutable();
        boolean pass = right.equals(R1);
        if (!pass) {
            return Result.fail(500, "密文不合法");
        }

        Element R4 = authRequest.getR4();
        Element acd = authRequest.getClientAcd().getImmutable();
        if (!acd.equals(R4.sub(R1).getImmutable())) {
            return Result.fail(500, "客户端身份账号Acd不合法");
        }

        long timestamp = System.currentTimeMillis();
        String idc = id;
        Element acd_c = acd.mulZn(c).getImmutable();
        Element h1 = Hash.h1((idc + timestamp).getBytes(StandardCharsets.UTF_8), acd_c, G1);
        Element key = Hash.h2(h1.toBytes(),R1,Zr);
        byte[] mac = HashUtils.sha256(ByteUtils.concat(key.toBytes(),h1.toBytes()));
        AuthResponse response = new AuthResponse();
        response.setServerId(id);
        response.setClientId(client.getId());
        response.setAuthMessage(new String(CurveUtils.curveConvertToMessage(m)));
        response.setTimestamp(timestamp);
        response.setMac(mac);
        response.setSessionKey(key.toBytes());
        boolean clientVerify = verifyByClient(client, response, auth);
        if (!clientVerify){
            return Result.fail(500,"客户端验证Mac失败");
        }
        return Result.ok(response);
    }

    public boolean verifyByClient(Client client, AuthResponse authResponse, Auth auth){
        String serverId = authResponse.getServerId();
        long timestamp = authResponse.getTimestamp();
        Field G1 = systemParam.getCurveBaseParam().getG1Field();
        Field Zr = systemParam.getCurveBaseParam().getZrField();
        Element acd = G1.newElementFromBytes(
                Base64Utils.decodeFromString(client.getAcd())
        ).getImmutable();
        Element R1 =  G1.newElementFromBytes(Base64Utils.decodeFromString(auth.getR1())).getImmutable();
        Element c =  Zr.newElementFromBytes(Base64Utils.decodeFromString(auth.getC())).getImmutable();
        Element acd_c = acd.mulZn(c).getImmutable();
        Element h1 = Hash.h1((serverId + timestamp).getBytes(StandardCharsets.UTF_8), acd_c, G1);
        Element key = Hash.h2(h1.toBytes(),R1,Zr);
        byte[] mac = HashUtils.sha256(ByteUtils.concat(key.toBytes(),h1.toBytes()));
        return Arrays.equals(mac, authResponse.getMac());
    }

}
