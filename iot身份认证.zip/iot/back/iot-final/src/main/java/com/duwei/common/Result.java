package com.duwei.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * <p>
 * 通用结果返回类
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-25 10:34
 * @since: 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {
    private Integer code;
    private String message;
    private T data;

    private Result(ResultCode resultCode) {
        this.code = resultCode.code;
        this.message = resultCode.reason;
    }

    public static <T> Result<T> ok(T data) {
        Result<T> result = new Result<T>(ResultCode.OK);
        result.data = data;
        return result;
    }

    public static <T> Result<T> fail(Integer code,String reason) {
        Result<T> result = new Result<T>();
        result.code = code;
        result.message = reason;
        return result;
    }

    public static <T> Result<T> fail(Integer code,String reason,T data) {
        Result<T> result = new Result<T>();
        result.code = code;
        result.message = reason;
        result.data = data;
        return result;
    }

    public static <T> Result<T> fail(ResultCode resultCode) {
        return new Result<T>(resultCode);
    }



    @AllArgsConstructor
    public enum ResultCode {
        /**
         * 成功
         */
        OK(20000, "Ok"),
        /**
         * 3XX 网络管理者失败
         * 300 获取网络管理者的公共参数失败
         */
        QUERY_PARAM_FAIL(300,"query public param fail"),
        /**
         * 4XX PKI客户端失败
         */
        PKI_CLIENT_VERIFY_FAIL(400,"client verify fail"),
        /**
         * 5XX CLC服务器失败
         */
        CLC_SERVER_VERIFY_FAIL(500,"server verify fail");


        private final Integer code;
        private final String reason;

        public Integer getCode() {
            return code;
        }

        public String getReason() {
            return reason;
        }
    }
}
