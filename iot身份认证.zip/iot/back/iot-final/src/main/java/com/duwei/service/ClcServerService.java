package com.duwei.service;

import com.duwei.cache.ClcServerCache;
import com.duwei.cache.PkiClientCache;
import com.duwei.common.Result;
import com.duwei.curve.algorithm.SignCryption;
import com.duwei.dao.ClcServerDao;
import com.duwei.dao.PkiClientDao;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.entity.Server;
import com.duwei.entity.internal.ClcServer;
import com.duwei.entity.internal.PkiClient;
import com.duwei.param.SystemParam;
import com.duwei.session.ClcServerHolder;
import com.duwei.session.PkiClientHolder;
import com.duwei.start.NetworkManager;
import com.duwei.util.HashUtils;
import com.duwei.util.TokenUtils;
import com.duwei.vo.LoginVO;
import com.duwei.vo.request.AuthRequest;
import com.duwei.vo.request.RegisterRequest;
import com.duwei.vo.response.AuthResponse;
import com.duwei.vo.response.ClientLoginResponse;
import com.duwei.vo.response.ServerLoginResponse;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Service
@SuppressWarnings("rawtypes")
public class  ClcServerService {
    @Resource
    private NetworkManager networkManager;
    @Resource
    private ClcServerDao clcServerDao;
    @Resource
    private AuthService authService;
    @Resource
    private PkiClientDao pkiClientDao;


    public Result<Server> register(RegisterRequest registerRequest) {
        String id = registerRequest.getId();
        String seed = registerRequest.getSeed();
        // 1.查询对应的serverId是否存在，不允许重复
        Server server = clcServerDao.queryServer(id);
        if (server != null){
            return Result.fail(500,"服务器ID重复，请重新注册");
        }

        // 2.构建PKI客户端实例
         ClcServer clcServer = new ClcServer(id,seed,networkManager.getSystemParam());

        // 3. 进行注册
        List<Element> elements = networkManager.registerServer(id);

        // 4.PKI客户端进行验证
        boolean success = clcServer.verify(elements.get(0), elements.get(1), elements.get(2));
        if (!success){
            return Result.fail(500,"服务端验证失败");
        }

        // 5.将客户端信息放入数据库
        server = convert(clcServer);
        clcServerDao.saveServer(server);

        return Result.ok(server);
    }

    public Result<ServerLoginResponse> login(LoginVO loginVO) {
        String id = loginVO.getId();
        String seed = loginVO.getSeed();
        seed = Base64Utils.encodeToString(HashUtils.sha256(seed.getBytes(StandardCharsets.UTF_8)));
        Server server = clcServerDao.queryServer(id, seed);
        if (server == null){
            return Result.fail(500,"账号不存在或者种子错误");
        }
        String token = TokenUtils.token();
        ClcServer clcServer = new ClcServer(server,loginVO.getSeed(),networkManager.getSystemParam());
        ClcServerCache.INSTANCE.addCache(token,clcServer);
        return Result.ok(new ServerLoginResponse(server, token));
    }


    private Server convert(ClcServer clcServer){
        Server server = new Server();
        server.setId(clcServer.getId());
        server.setPrivateSeed(Base64Utils.encodeToString(HashUtils.sha256(clcServer.getSeed().getBytes(StandardCharsets.UTF_8))));
        server.setGama(Base64Utils.encodeToString(clcServer.getGama().toBytes()));
        server.setPublicFirst(Base64Utils.encodeToString(clcServer.getPublicKeyPair().getFirst().toBytes()));
        server.setPublicSecond(Base64Utils.encodeToString(clcServer.getPublicKeyPair().getSecond().toBytes()));
        server.setPrivateFirst(Base64Utils.encodeToString(clcServer.getPrivateKeyPair().getFirst().toBytes()));
        return server;
    }


    public Result<List<Auth>> queryAllAuths() {
        String serverId = ClcServerHolder.get().getId();
        return  authService.queryByServerId(serverId);
    }


    public Result<AuthResponse> authByAuthRequestId(String authId) {
        Auth auth = authService.query(authId);
        if (auth == null){
            return Result.fail(500,"认证请求不存在，服务器无法进行认证");
        }
        if (auth.getStatus() == 1){
            return Result.fail(500,"该请求认证成功，无需重新认证");
        }
        if (auth.getStatus() == 2){
            return Result.fail(500,"该请求认证失败，请重新认证");
        }

        Client client = pkiClientDao.queryClient(auth.getClientId());
        String pk = client.getPk();
        AuthRequest authRequest = convert(auth, Base64Utils.decodeFromString(pk), Base64Utils.decodeFromString(client.getAcd()),networkManager.getSystemParam());

        ClcServer clcServer = ClcServerHolder.get();
        Result<AuthResponse> authResponseResult = clcServer.auth(authRequest, client, auth);
        if (!authResponseResult.getCode().equals(Result.ResultCode.OK.getCode())) {
            auth.setStatus(2);
        }else {
            auth.setStatus(1);
        }
        authService.update(auth);
        return authResponseResult;
    }

    public AuthRequest convert(Auth auth, byte[] pk,byte[] clientAcdByte,SystemParam systemParam){
        Field Zr = systemParam.getCurveBaseParam().getZrField();
        Field G1 = systemParam.getCurveBaseParam().getG1Field();
        byte[] R4Bytes = Base64Utils.decodeFromString(auth.getR4());
        byte[] R1Bytes = Base64Utils.decodeFromString(auth.getR1());
        byte[] UBytes = Base64Utils.decodeFromString(auth.getU());
        byte[] CBytes = Base64Utils.decodeFromString(auth.getC());

        Element R4 = G1.newElementFromBytes(R4Bytes).getImmutable();
        Element R1 = G1.newElementFromBytes(R1Bytes).getImmutable();
        Element U = G1.newElementFromBytes(UBytes).getImmutable();
        Element C = Zr.newElementFromBytes(CBytes).getImmutable();
        Element clientPublicKey = G1.newElementFromBytes(pk).getImmutable();
        Element acd = G1.newElementFromBytes(clientAcdByte).getImmutable();

        AuthRequest authRequest = new AuthRequest();
        authRequest.setClientId(auth.getClientId());
        authRequest.setR4(R4);
        authRequest.setClientPublicKey(clientPublicKey);
        authRequest.setClientAcd(acd);

        SignCryption.SignCryptionText signCryptionText = new SignCryption.SignCryptionText();
        signCryptionText.setMessageLen(auth.getMessageLen());
        signCryptionText.setR2(Base64Utils.decodeFromString(auth.getR2()));
        signCryptionText.setR3(Base64Utils.decodeFromString(auth.getR3()));
        signCryptionText.setR1(R1);
        signCryptionText.setC(C);
        signCryptionText.setU(U);
        authRequest.setSignCryptionText(signCryptionText);
        return authRequest;
    }

    public Result<Server> getInfo() {
        ClcServer clcServer = ClcServerHolder.get();
        return Result.ok(clcServerDao.queryServer(clcServer.getId()));
    }

    public Result<List<Auth>> queryAuths() {
        ClcServer clcServer = ClcServerHolder.get();
        return authService.queryByServerId(clcServer.getId());
    }
}
