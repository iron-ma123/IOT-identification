package com.duwei.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:13
 * @since: 1.0
 */
public abstract class Cache<K, V> {
    private final Map<K, V> CACHE = new ConcurrentHashMap<>();
    /**
     * 缓存的超时时间
     */
    public static final long CACHE_TIMEOUT = 30 * 60 * 1000;
    /**
     * 执行清理任务的线程池
     */
    public static final ScheduledExecutorService CLEAN_POOL = new ScheduledThreadPoolExecutor(1);

    private class CleanCacheRunnable implements Runnable {
        private final K key;

        public CleanCacheRunnable(K key) {
            this.key = key;
        }

        @Override
        public void run() {
            CACHE.remove(key);
        }
    }

    public void addCache(K key, V val) {
        CACHE.put(key, val);
        CLEAN_POOL.schedule(new CleanCacheRunnable(key), CACHE_TIMEOUT, TimeUnit.SECONDS);
    }

    public V getCache(K key) {
        return CACHE.get(key);
    }

    public boolean contains(K key) {
        return CACHE.containsKey(key);
    }

    public V remove(K key) {
        return CACHE.remove(key);
    }


}
