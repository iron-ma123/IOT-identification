package com.duwei.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:50
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterVO {
    private String id;
    private String seed;
}
