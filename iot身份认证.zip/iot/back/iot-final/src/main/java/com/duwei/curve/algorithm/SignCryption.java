package com.duwei.curve.algorithm;

import com.duwei.common.Pair;
import com.duwei.curve.element.CurveFieldElement;
import com.duwei.curve.element.ZrFieldElement;
import com.duwei.entity.Server;
import com.duwei.entity.internal.ClcServer;
import com.duwei.param.Hash;
import com.duwei.param.SystemParam;
import com.duwei.util.ByteUtils;
import com.duwei.util.CurveUtils;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.Base64Utils;

import java.util.Arrays;


/**
 * <p>
 * 签密算法
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-30 15:52
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
public class SignCryption {
    public static SignCryptionText crypt(
            String message,
            Element sk,
            SystemParam param,
            Element gama,
            Pair<Element, Element> serverPublicKeyPair,
            Server server) {
        // 公共参数
        Field Zr = param.getCurveBaseParam().getZrField();
        Field G1 = param.getCurveBaseParam().getG1Field();
        Element P = param.getGeneratorOnG1Field();
        Element pPub = param.getSystemPublicKey();

        // 消息嵌入到椭圆曲线上
        Element m = CurveUtils.messageEmbedToCurve(message, G1);
        byte[] k = ByteUtils.random(256);
        Element r = Hash.h2(k, m, Zr);
        Element R1 = P.mulZn(r).getImmutable();

        byte[] R2 = ByteUtils.xor(m.toBytes(), Hash.h3(k));
        byte[] R3 = ByteUtils.xor(k, Hash.h3(R2));

        Element T = serverPublicKeyPair.getFirst();
        Element pkc = serverPublicKeyPair.getSecond();
        System.out.println(Arrays.toString(m.toBytes()));
        Element gama_pk = pPub.mulZn(gama).getImmutable();
        Element U = pkc.mulZn(r).getImmutable().add(T).getImmutable().add(gama_pk).getImmutable();
        Element c = (sk.mul(Hash.h4(m.toBytes(), Zr)).getImmutable()).add(r).getImmutable();

        return new SignCryptionText(
                c,
                R1,
                R2,
                R3,
                U,
                m.toBytes().length
        );
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SignCryptionText {
        private Element c;
        private Element R1;
        private byte[] R2;
        private byte[] R3;
        private Element U;
        private int messageLen;

    }
}
