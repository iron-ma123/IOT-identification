package com.duwei.dao;

import com.duwei.curve.medatada.TypeACurveMetadata;
import com.duwei.param.SystemKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Repository
public class SystemParamDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public TypeACurveMetadata queryCurveMetadata() {
        String sql = "select * from curve_metadata";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(TypeACurveMetadata.class));
    }

    public void saveMetadata(TypeACurveMetadata typeACurveMetadata) {
        String sql = "insert into curve_metadata values(null,?,?,?,?,?,?,?,?) ";
        jdbcTemplate.update(sql,
                typeACurveMetadata.getType(),
                typeACurveMetadata.getQ(),
                typeACurveMetadata.getR(),
                typeACurveMetadata.getH(),
                typeACurveMetadata.getExp1(),
                typeACurveMetadata.getExp2(),
                typeACurveMetadata.getSign0(),
                typeACurveMetadata.getSign0());
    }

    public SystemKey querySystemKey(){
        String sql = "select * from system_key";
        return jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper<>(SystemKey.class));
    }
}
