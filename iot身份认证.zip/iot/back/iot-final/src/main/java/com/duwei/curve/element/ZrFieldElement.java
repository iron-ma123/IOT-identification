package com.duwei.curve.element;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.plaf.jpbc.field.z.ZrElement;
import it.unisa.dia.gas.plaf.jpbc.field.z.ZrField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 * <p>
 * 对jpbc的ZrElement进行的封装，可以进行传输和序列化
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 11:29
 * @since: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuppressWarnings("rawtypes")
public class ZrFieldElement extends AbstractFieldElement {
    @Override
    protected void checkElement(Element element) {
        if (!(element instanceof ZrElement)) {
            throw new RuntimeException("element 必须是 ZrElement 类型 ");
        }
    }

    public ZrFieldElement(Element element){
        super(element);
    }

    @Override
    protected void checkField(Field field) {
        if (!(field instanceof ZrField)) {
            throw new RuntimeException("field 必须是 ZrField 类型");
        }
    }

}
