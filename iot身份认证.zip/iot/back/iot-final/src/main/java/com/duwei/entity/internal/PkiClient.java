package com.duwei.entity.internal;

import com.duwei.common.Pair;
import com.duwei.curve.algorithm.SignCryption;
import com.duwei.curve.element.CurveFieldElement;
import com.duwei.curve.medatada.CurveMetadata;
import com.duwei.curve.medatada.TypeACurveMetadata;
import com.duwei.curve.param.CurveBaseParam;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.entity.Server;
import com.duwei.param.SystemParam;
import com.duwei.util.HashUtils;
import com.duwei.vo.SystemParamVO;
import com.duwei.vo.request.AuthRequest;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import lombok.Data;
import org.springframework.util.Base64Utils;

import java.nio.charset.StandardCharsets;


/**
 * <p>
 * 处于PKI密码体制下的客户端
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-25 09:15
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
@Data
public class PkiClient {
    /**
     * 私钥种子
     */
    private String seed;
    /**
     * 私钥
     */
    private Element xp;
    /**
     * 公钥
     */
    private Element pk;
    /**
     * 用户ID
     */
    private String id;
    /**
     * 公共参数
     */
    private SystemParam systemParam;
    /**
     * 身份账号
     */
    private Element acd;
    private Element sigma;
    private Element delta;


    public PkiClient(String id, String seed, SystemParam systemParam) {
        this.id = id;
        this.seed = seed;
        this.systemParam = systemParam;
        this.init();
    }

    public PkiClient(Client client, String seed, SystemParam systemParam) {
        this.id = client.getId();
        this.seed = seed;
        this.systemParam = systemParam;
        this.init();
        this.buildInternal(client.getAcd(), client.getSigma(), client.getDelta());
    }


    private void init() {
        CurveBaseParam curveBaseParam = systemParam.getCurveBaseParam();
        Field zrField = curveBaseParam.getZrField();
        byte[] hash = HashUtils.sha256(seed.getBytes(StandardCharsets.UTF_8));
        Element generatorOnG1Field = systemParam.getGeneratorOnG1Field();
        this.xp = zrField.newElementFromHash(hash, 0, hash.length).getImmutable();
        this.pk = generatorOnG1Field.mulZn(xp).getImmutable();
    }

    public void buildInternal(String acd, String sigma, String delta) {
        byte[] acdByte = Base64Utils.decodeFromString(acd);
        byte[] sigmaByte = Base64Utils.decodeFromString(sigma);
        byte[] deltaByte = Base64Utils.decodeFromString(delta);

        Field zrField = systemParam.getCurveBaseParam().getZrField();
        Field g1Field = systemParam.getCurveBaseParam().getG1Field();
        this.acd = g1Field.newElementFromBytes(acdByte).getImmutable();
        this.delta = zrField.newElementFromBytes(deltaByte).getImmutable();
        this.sigma = zrField.newElementFromBytes(sigmaByte).getImmutable();
    }


    public Auth authServer(String message, Server server) {
        Field Zr = getSystemParam().getCurveBaseParam().getZrField();
        Field G1 = getSystemParam().getCurveBaseParam().getG1Field();
        Element gama = Zr.newElementFromBytes(Base64Utils.decodeFromString(server.getGama())).getImmutable();
        String publicFirst = server.getPublicFirst();
        String publicSecond = server.getPublicSecond();
        Pair<Element, Element> publicKeyPair = new Pair<>(
                G1.newElementFromBytes(Base64Utils.decodeFromString(publicFirst)).getImmutable(),
                G1.newElementFromBytes(Base64Utils.decodeFromString(publicSecond)).getImmutable()
        );
        return authServer(message, server.getId(), gama, publicKeyPair,server);
    }

    // 客户端构建服务请求消息
    private Auth authServer(String message,
                            String serverId,
                            Element gama,
                            Pair<Element, Element> serverPublicKeyPair,
                            Server server) {
        SignCryption.SignCryptionText cryptionText = SignCryption.crypt(message, xp, systemParam, gama, serverPublicKeyPair,server);
        Element R1 = cryptionText.getR1().getImmutable();
        Element R4 = R1.add(acd).getImmutable();
        Auth auth = new Auth();
        auth.setClientId(id);
        auth.setServerId(serverId);
        auth.setC(Base64Utils.encodeToString(cryptionText.getC().toBytes()));
        auth.setR1(Base64Utils.encodeToString(cryptionText.getR1().toBytes()));
        auth.setR2(Base64Utils.encodeToString(cryptionText.getR2()));
        auth.setR3(Base64Utils.encodeToString(cryptionText.getR3()));
        auth.setR4(Base64Utils.encodeToString(R4.toBytes()));
        auth.setU(Base64Utils.encodeToString(cryptionText.getU().toBytes()));
        auth.setMessageLen(cryptionText.getMessageLen());
        auth.setStatus(Auth.AuthStatus.WAIT_AUTH.getCode());
        return auth;
    }


    public boolean verify(Element acdElement, Element deltaElement, Element sigmaElement) {
        Element P = systemParam.getGeneratorOnG1Field().getImmutable();
        Element pPub = systemParam.getSystemPublicKey().getImmutable();
        this.acd = acdElement;
        Element temp1 = P.mulZn(sigmaElement).getImmutable();
        Element temp2 = pPub.mulZn(deltaElement).getImmutable();
        Element right = temp1.sub(temp2).getImmutable();
        boolean success = right.equals(acdElement);
        if (success) {
            this.acd = acdElement.getImmutable();
            this.sigma = sigmaElement.getImmutable();
            this.delta = deltaElement.getImmutable();
        }
        return success;
    }


//
//    public ClientRegisterRequest buildRegisterRequest() {
//        ClientRegisterRequest request = new ClientRegisterRequest();
//        request.setId(id);
//        request.setPrivateSeedHash(Base64Utils.encodeToString(HashUtils.sha256(seed.getBytes(StandardCharsets.UTF_8))));
//        request.setClientPublicKey(new CurveFieldElement(pk));
//        return request;
//    }
}
