package com.duwei.dao;

import com.duwei.entity.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Repository
public class PkiClientDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Client queryClient(String id, String seed) {
        String sql = "select * from client where id = ? and private_seed = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id, seed}, new BeanPropertyRowMapper<>(Client.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public void saveClient(Client client) {
        String sql = "insert into client values(?,?,?,?,?,?)";
        jdbcTemplate.update(sql, client.getId(), client.getAcd(), client.getSigma(), client.getDelta(), client.getPk(), client.getPrivateSeed());
    }

    public Client queryClient(String id) {
        String sql = "select * from client where id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(Client.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public List<Client> queryClients() {
        String sql = "select * from client";
        try {
            return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Client.class))
                    .stream()
                    .peek(client -> client.setPrivateSeed(null))
                    .collect(Collectors.toList());
        } catch (Exception ignored) {

        }
        return null;
    }
}
