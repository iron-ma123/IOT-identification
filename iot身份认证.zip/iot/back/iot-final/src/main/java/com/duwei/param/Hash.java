package com.duwei.param;

import com.duwei.util.HashUtils;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;

/**
 * <p>
 * 公共的hash函数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-24 16:52
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
public class Hash {

    public static Element h0(byte[] sequence, Field zrField) {
        return HashUtils.hashToZrElementBySha256(sequence, zrField);
    }

    public static Element h1(byte[] sequence, Element curveElement, Field curveField) {
        return HashUtils.hashToElementBySha256(sequence, curveElement, curveField);
    }

    public static Element h2(byte[] sequence, Element curveElement, Field zrField) {
        return HashUtils.hashToElementBySha256(sequence, curveElement, zrField);
    }

    /**
     * 默认n为256字节
     */
    public static byte[] h3(byte[] sequence){
        return HashUtils.sha256(sequence);
    }

    public static Element h4(byte[] sequence,Field zrField){
        return HashUtils.hashToZrElementBySha256(sequence,zrField);
    }
}
