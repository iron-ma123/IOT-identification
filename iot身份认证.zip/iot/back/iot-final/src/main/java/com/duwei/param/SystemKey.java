package com.duwei.param;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *  系统参数
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 17:24
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemKey {
    /**
     * 用于网络管理者的秘密种子
     */
    private String secretSeed;
    /**
     * 用于网络管理者的生成元参数
     */
    private String generatorSeed;
}
