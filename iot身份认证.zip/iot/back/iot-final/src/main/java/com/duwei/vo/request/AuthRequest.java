package com.duwei.vo.request;

import com.duwei.curve.algorithm.SignCryption;
import com.duwei.curve.element.CurveFieldElement;
import it.unisa.dia.gas.jpbc.Element;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 *  客户端向服务器的认证请求
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-30 16:33
 * @since: 1.0
 */
@Data
@NoArgsConstructor
public class AuthRequest {
    private String clientId;
    private SignCryption.SignCryptionText signCryptionText;
    private Element R4;
    private Element clientPublicKey;
    private Element clientAcd;

    public AuthRequest(SignCryption.SignCryptionText cryptionText, Element r4) {
        this.signCryptionText = cryptionText;
        this.R4 = r4;
    }

    public AuthRequest(String id, SignCryption.SignCryptionText cryptionText, Element r4) {
        this(cryptionText,r4);
        this.clientId = id;
    }
}
