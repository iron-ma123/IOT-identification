package com.duwei.util;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <p>
 * 哈希函数工具类
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-24 16:47
 * @since: 1.0
 */
@SuppressWarnings("rawtypes")
public class HashUtils {
    private static final MessageDigest MESSAGE_DIGEST_SHA_256;
    private static final MessageDigest MESSAGE_DIGEST_SHA_512;

    static {
        try {
            MESSAGE_DIGEST_SHA_256 = MessageDigest.getInstance("SHA-256");
            MESSAGE_DIGEST_SHA_512 = MessageDigest.getInstance("SHA-512");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * sha256 哈希算法
     */
    public static byte[] sha256(byte[] sequence) {
        return MESSAGE_DIGEST_SHA_256.digest(sequence);
    }

    /**
     * sha512 哈希算法
     */
    public static byte[] sha512(byte[] sequence) {
        return MESSAGE_DIGEST_SHA_512.digest(sequence);
    }


    /**
     * 将比特序列hash过后映射到ZrField域上
     */
    public static Element hashToZrElementBySha256(byte[] sequence, Field zrField) {
        return CurveUtils.hashToZrElement(sha256(sequence), zrField);
    }



    /**
     * 将比特序列和元素  hash过后映射到Field域上
     */
    public static Element hashToElementBySha256(byte[] sequence, Element curveElement, Field zrField) {
        byte[] data = ByteUtils.concat(sequence, curveElement.toBytes());
        return CurveUtils.hashToZrElement(sha256(data), zrField);
    }

}
