package com.duwei.service;

import com.duwei.common.Result;
import com.duwei.curve.element.CurveFieldElement;
import com.duwei.curve.medatada.TypeACurveMetadata;
import com.duwei.dao.SystemParamDao;
import com.duwei.param.SystemKey;
import com.duwei.param.SystemParam;
import com.duwei.start.NetworkManager;
import com.duwei.vo.SystemParamVO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Service
public class SystemParamService {
    @Resource
    private SystemParamDao systemParamDao;
    @Resource
    private NetworkManager networkManager;

    public Result<TypeACurveMetadata> queryMetadata() {
        TypeACurveMetadata metadata = systemParamDao.queryCurveMetadata();
        if (metadata == null) {
            systemParamDao.saveMetadata(TypeACurveMetadata.DEFAULT);
        }
        return Result.ok(metadata);
    }

    public Result<SystemParamVO> querySystemParam() {
        SystemParam systemParam = networkManager.getSystemParam();
        SystemParamVO vo = new SystemParamVO();

        vo.setCurveMetadata(systemParam.getCurveBaseParam().getCurveMetadata());
        vo.setGeneratorOnG1Field(systemParam.getGeneratorOnG1Field().toBytes());
        vo.setSystemPublicKey(systemParam.getSystemPublicKey().toBytes());
        return Result.ok(vo);

    }
}
