package com.duwei.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <p>
 * 认证请求
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 14:55
 * @since: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Auth {
    private Integer id;
    private String clientId;
    private String serverId;
    private String c;
    private String r1;
    private String r2;
    private String r3;
    private String r4;
    private String u;
    private int messageLen;
    private int status;

    public enum AuthStatus {
        /**
         * 等待服务器认证
         */
        WAIT_AUTH(0),
        /**
         * 认证成功
         */
        AUTH_SUCCESS(1),
        /**
         * 认证失败
         */
        AUTH_FAIL(2);


        private final int code;

        AuthStatus(int code) {
            this.code = code;
        }

        public int getCode() {
            return code;
        }
        }
}
