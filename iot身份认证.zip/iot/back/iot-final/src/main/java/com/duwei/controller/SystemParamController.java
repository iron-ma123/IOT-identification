package com.duwei.controller;

import com.duwei.common.Result;
import com.duwei.service.SystemParamService;
import com.duwei.vo.SystemParamVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@RestController
@CrossOrigin
@RequestMapping("/curve")
public class SystemParamController {
    @Autowired
    SystemParamService systemParamService;

    @GetMapping("/param")
    public Result<SystemParamVO> querySystemParam() {
        return systemParamService.querySystemParam();
    }
}
