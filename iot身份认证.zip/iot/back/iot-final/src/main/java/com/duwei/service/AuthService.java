package com.duwei.service;

import com.duwei.common.Result;
import com.duwei.dao.AuthDao;
import com.duwei.entity.Auth;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 15:05
 * @since: 1.0
 */
@Service
public class AuthService {
    @Resource
    private AuthDao authDao;

    public void save(Auth auth) {
        authDao.saveAuth(auth);
    }

    public Auth query(String clientId, String serverId) {
        return authDao.queryById(clientId, serverId);
    }

    public Auth queryNoAuth(String clientId, String serverId) {
        return authDao.queryIdAndState(clientId, serverId, 0);
    }

    public Auth queryAuthSuccess(String clientId, String serverId) {
        return authDao.queryIdAndState(clientId, serverId, 1);
    }

    public Auth queryAuthFailed(String clientId, String serverId) {
        return authDao.queryIdAndState(clientId, serverId, 2);
    }

    public Auth query(String id) {
        return authDao.queryById(id);
    }


    public Result<List<Auth>> queryByServerId(String serverId) {
        return Result.ok(authDao.queryByServerId(serverId));
    }

    public Result<List<Auth>> queryByClientId(String clientId) {
        return Result.ok(authDao.queryByClientId(clientId));
    }

    public void update(Auth auth) {
        authDao.updateAuth(auth);
    }
}
