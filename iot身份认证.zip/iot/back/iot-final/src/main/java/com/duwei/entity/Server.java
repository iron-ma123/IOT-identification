package com.duwei.entity;

import lombok.Data;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-27 11:10
 * @since: 1.0
 */
@Data
public class Server {
    private String id;
    private String privateFirst;
    private String publicFirst;
    private String publicSecond;
    private String gama;
    /**
     * 用于服务器登录
     */
    private String privateSeed;
}
