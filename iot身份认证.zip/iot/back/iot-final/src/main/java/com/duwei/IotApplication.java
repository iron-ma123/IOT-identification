package com.duwei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:38
 * @since: 1.0
 */
@SpringBootApplication
public class IotApplication {
    public static void main(String[] args) {
        SpringApplication.run(IotApplication.class,args);
    }
}
