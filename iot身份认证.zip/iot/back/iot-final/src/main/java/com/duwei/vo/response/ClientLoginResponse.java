package com.duwei.vo.response;

import com.duwei.entity.Client;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:32
 * @since: 1.0
 */
@Data
@AllArgsConstructor
public class ClientLoginResponse {
    private Client client;
    // 登录凭证
    private String token;
}
