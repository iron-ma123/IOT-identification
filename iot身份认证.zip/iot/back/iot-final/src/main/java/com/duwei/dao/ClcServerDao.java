package com.duwei.dao;

import com.duwei.entity.Client;
import com.duwei.entity.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@Repository
public class ClcServerDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Server queryServer(String id) {
        String sql = "select * from server where id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(Server.class));
        } catch (Exception ignored) {

        }
        return null;
    }


    public Server queryServer(String id, String seed) {
        String sql = "select * from server where id = ? and private_seed = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id, seed}, new BeanPropertyRowMapper<>(Server.class));
        } catch (Exception ignored) {

        }
        return null;
    }

    public void saveServer(Server server) {
        String sql = "insert into server values(?,?,?,?,?,?)";
        jdbcTemplate.update(
                sql, server.getId(),
                server.getPrivateFirst(),
                server.getPublicFirst(),
                server.getPublicSecond(),
                server.getGama(),
                server.getPrivateSeed());
    }

    public List<Server> queryServers() {
        String sql = "select * from server";
        try {
            return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Server.class))
                    .stream()
                    .peek(server -> server.setPrivateSeed(null))
                    .collect(Collectors.toList());
        } catch (Exception ignored) {

        }
        return null;
    }
}
