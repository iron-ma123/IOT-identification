package com.duwei.controller;

import com.duwei.common.Result;
import com.duwei.entity.Auth;
import com.duwei.entity.Client;
import com.duwei.entity.Server;
import com.duwei.service.PkiClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2024-04-26 08:57
 * @since: 1.0
 */
@RestController
@CrossOrigin
@RequestMapping("/pki-client/api")
public class ClientApiController {
    @Autowired
    private PkiClientService pkiClientService;

    @GetMapping("/getInfo")
    public Result<Client> getInfo(){
        return pkiClientService.getInfo();
    }

    @GetMapping("/query-servers")
    public Result<List<Server>> queryServers() {
        return pkiClientService.queryServers();
    }


    @GetMapping("query-auths")
    public Result<List<Auth>> queryAuths(){
        return pkiClientService.queryAuths();
    }

}
