package com.duwei.controller;

import com.duwei.common.Result;
import com.duwei.entity.Auth;
import com.duwei.entity.Server;
import com.duwei.service.ClcServerService;
import com.duwei.vo.LoginVO;
import com.duwei.vo.request.RegisterRequest;
import com.duwei.vo.response.AuthResponse;
import com.duwei.vo.response.ServerLoginResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 09:07
 * @since: 1.0
 */
@RestController
@CrossOrigin
@RequestMapping("/clc-server")
public class ClcServerController {
    @Autowired
    private ClcServerService clcServerService;

    @PostMapping("/register")
    public Result<Server> register(@RequestBody RegisterRequest registerRequest) {
        return clcServerService.register(registerRequest);
    }

    @PostMapping("/login")
    public Result<ServerLoginResponse> login(@RequestBody LoginVO loginVO){
        return clcServerService.login(loginVO);
    }

    @GetMapping("/auths")
    public Result<List<Auth>> queryAllAuths(){
        return clcServerService.queryAllAuths();
    }

    @GetMapping("/auth/{authId}")
    public Result<AuthResponse> authByAuthRequestId(@PathVariable("authId")String authId){
        return clcServerService.authByAuthRequestId(authId);
    }
}
