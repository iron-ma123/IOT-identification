package com.duwei.curve.medatada;

import it.unisa.dia.gas.plaf.jpbc.pairing.parameters.PropertiesParameters;

/**
 * <p>
 * 椭圆曲线的初始化适配器
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-26 15:16
 * @since: 1.0
 */
public class CurvePropertiesParametersAdapter extends PropertiesParameters {
    public CurvePropertiesParametersAdapter(CurveMetadata metaProperties) {
        this.parameters.putAll(metaProperties.extractMetadata());
    }

    public CurvePropertiesParametersAdapter() {
    }
}
