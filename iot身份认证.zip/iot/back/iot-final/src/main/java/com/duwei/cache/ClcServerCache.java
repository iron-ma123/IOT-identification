package com.duwei.cache;

import com.duwei.entity.internal.ClcServer;

/**
 * <p>
 *
 * <p>
 *
 * @author: duwei
 * @date: 2023-10-31 10:12
 * @since: 1.0
 */
public class ClcServerCache extends Cache<String, ClcServer> {
    public static final ClcServerCache INSTANCE = new ClcServerCache();

    public static void add(String token, ClcServer clcServer) {
        INSTANCE.addCache(token, clcServer);
    }

    public static ClcServer get(String token) {
        return INSTANCE.getCache(token);
    }


}
